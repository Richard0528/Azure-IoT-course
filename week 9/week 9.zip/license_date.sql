INSERT INTO license_plate (LicenseID, Creation_date, Sex, Address, Birth_date, Plate_number, Name)
VALUES ('SMITHJ381CW*', '10/16/2018', 'M', 'Washington', '5/10/1980', '554 BEN', 'John Smith'),
('L00775511921', '03/10/2017', 'M', 'Michigan', '5/22/1988', 'KZH G8165', 'Ben Liu'),
('Y00000095600', '12/20/2017', 'F', 'Wisconsin', '3/20/1995', '579-XVH', 'Alan Yu'),
('D28538*7*340', '2/28/2017', 'F', 'Arizona', '9/14/1980', 'PT9442', 'Celina Kerns'),
('576435*51*41', '8/08/2017', 'M', 'Hawaii', '10/10/1977', 'WVR 166', 'Chamber Lee'),
('MARRIC64*8YB', '12/12/2017', 'M', 'Washington', '10/22/1987', '922 BJM', 'Christopher Marriott'),
('CARD*R551RS*', '12/30/2017', 'M', 'Washington', '7/12/1979', '236 ANV', 'Ryan Card'),
('91-805-485*2', '5/12/2018', 'F', 'Penneylvania', '1/22/1996', 'PEM-9454', 'Bill Leslie');